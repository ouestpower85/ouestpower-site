OUSTPOWER — SITE INTERNET

Fichiers :
- index.html : accueil
- presentation.html : présentation de l'entreprise
- tarifs.html : tarifs et prestations
- README.txt : instructions de publication

Publier gratuitement avec GitHub Pages :
1. Créez un compte sur https://github.com/
2. Créez un dépôt public, par exemple ouestpower-site.
3. Téléversez les trois fichiers HTML à la racine du dépôt (Add file > Upload files).
4. Ouvrez Settings > Pages.
5. Choisissez Deploy from a branch, branche main, dossier / (root), puis Save.
6. Attendez quelques minutes et récupérez l'URL dans Settings > Pages.

À vérifier avant publication :
- Le tarif FlexFuel de 450 € TTC est indiqué comme prix de départ indicatif : confirmez qu'il correspond bien à votre offre réelle.
- Remplacez le lien Instagram générique dans index.html par le lien de votre compte.
- Ajoutez des mentions légales complètes, notamment les informations légales de l'entreprise et de l'hébergeur.
- Le formulaire de contact de la page d'accueil ouvre l'application e-mail du visiteur ; il ne transmet pas les demandes à un serveur.
